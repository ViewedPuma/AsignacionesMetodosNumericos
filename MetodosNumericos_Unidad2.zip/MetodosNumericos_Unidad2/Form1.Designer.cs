﻿namespace MetodosNumericos_Unidad2
{
    partial class frmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button3 = new Button();
            button2 = new Button();
            PanelContenedor = new Panel();
            btnAsignacion07 = new Button();
            label5 = new Label();
            label3 = new Label();
            label1 = new Label();
            label2 = new Label();
            button1 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            SuspendLayout();
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(16, 48, 54);
            button3.Enabled = false;
            button3.Location = new Point(896, 423);
            button3.Name = "button3";
            button3.Size = new Size(207, 138);
            button3.TabIndex = 30;
            button3.Text = "Coming Soon";
            button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(16, 48, 54);
            button2.Enabled = false;
            button2.Location = new Point(647, 423);
            button2.Name = "button2";
            button2.Size = new Size(207, 138);
            button2.TabIndex = 29;
            button2.Text = "Coming Soon";
            button2.UseVisualStyleBackColor = false;
            // 
            // PanelContenedor
            // 
            PanelContenedor.Dock = DockStyle.Fill;
            PanelContenedor.Location = new Point(0, 0);
            PanelContenedor.Name = "PanelContenedor";
            PanelContenedor.Size = new Size(1262, 815);
            PanelContenedor.TabIndex = 28;
            PanelContenedor.Visible = false;
            // 
            // btnAsignacion07
            // 
            btnAsignacion07.BackColor = Color.FromArgb(16, 48, 54);
            btnAsignacion07.Location = new Point(140, 224);
            btnAsignacion07.Name = "btnAsignacion07";
            btnAsignacion07.Size = new Size(207, 138);
            btnAsignacion07.TabIndex = 27;
            btnAsignacion07.Tag = "chico";
            btnAsignacion07.Text = "Gauss,Gauss-Jordan";
            btnAsignacion07.UseVisualStyleBackColor = false;
            btnAsignacion07.Click += btnAsignacion07_Click;
            // 
            // label5
            // 
            label5.BackColor = Color.FromArgb(172, 109, 54);
            label5.Location = new Point(966, 683);
            label5.Name = "label5";
            label5.Size = new Size(197, 92);
            label5.TabIndex = 26;
            // 
            // label3
            // 
            label3.BackColor = Color.White;
            label3.Location = new Point(140, 752);
            label3.Name = "label3";
            label3.Size = new Size(207, 23);
            label3.TabIndex = 25;
            // 
            // label1
            // 
            label1.BackColor = Color.FromArgb(16, 48, 54);
            label1.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(99, 21);
            label1.Name = "label1";
            label1.Size = new Size(1048, 90);
            label1.TabIndex = 18;
            label1.Text = "Metodos Numericos Unidad 2";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Left;
            label2.BackColor = Color.FromArgb(16, 48, 54);
            label2.Location = new Point(99, 139);
            label2.Name = "label2";
            label2.Size = new Size(1048, 507);
            label2.TabIndex = 24;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(16, 48, 54);
            button1.Enabled = false;
            button1.Location = new Point(396, 224);
            button1.Name = "button1";
            button1.Size = new Size(207, 138);
            button1.TabIndex = 31;
            button1.Text = "Coming Soon";
            button1.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(16, 48, 54);
            button4.Enabled = false;
            button4.Location = new Point(647, 224);
            button4.Name = "button4";
            button4.Size = new Size(207, 138);
            button4.TabIndex = 32;
            button4.Text = "Coming Soon";
            button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(16, 48, 54);
            button5.Enabled = false;
            button5.Location = new Point(896, 224);
            button5.Name = "button5";
            button5.Size = new Size(207, 138);
            button5.TabIndex = 33;
            button5.Text = "Coming Soon";
            button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(16, 48, 54);
            button6.Enabled = false;
            button6.Location = new Point(396, 423);
            button6.Name = "button6";
            button6.Size = new Size(207, 138);
            button6.TabIndex = 34;
            button6.Text = "Coming Soon";
            button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(16, 48, 54);
            button7.Enabled = false;
            button7.Location = new Point(140, 423);
            button7.Name = "button7";
            button7.Size = new Size(207, 138);
            button7.TabIndex = 35;
            button7.Text = "Coming Soon";
            button7.UseVisualStyleBackColor = false;
            // 
            // frmMain
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(24, 77, 86);
            ClientSize = new Size(1262, 815);
            Controls.Add(PanelContenedor);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(btnAsignacion07);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "frmMain";
            Text = "frmMain";
            ResumeLayout(false);
        }

        #endregion

        private Button button3;
        private Button button2;
        private Panel PanelContenedor;
        private Button btnAsignacion07;
        private Label label5;
        private Label label3;
        private Label label1;
        private Label label2;
        private Button button1;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
    }
}
